/* eslint-disable @typescript-eslint/no-empty-function */
export const noop = () => {};
export const noopAsync = async () => {};
export const noopTrue = () => true;
/* eslint-enable @typescript-eslint/no-empty-function */
