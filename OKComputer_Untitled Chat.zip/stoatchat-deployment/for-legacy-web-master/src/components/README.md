The following folders should not be added to or modified:

-   `common`
-   `markdown`
-   `native`
-   `ui`

The following are part-legacy, will remain in place and will be rewritten to some degree still:

-   `navigation`

The following are mostly good to go:

-   `settings`
