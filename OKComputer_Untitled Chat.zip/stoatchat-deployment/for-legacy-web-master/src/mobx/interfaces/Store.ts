export default interface Store {
    get id(): string;
}
