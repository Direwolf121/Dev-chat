#[allow(clippy::module_inception)]
pub mod amqp;
